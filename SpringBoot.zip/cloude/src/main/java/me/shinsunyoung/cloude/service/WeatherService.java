package me.shinsunyoung.cloude.service;

import me.shinsunyoung.cloude.dto.WeatherDto;
import org.springframework.stereotype.Service;

@Service
public class WeatherService {


}
